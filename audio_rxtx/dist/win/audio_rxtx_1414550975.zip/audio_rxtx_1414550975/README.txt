audio_rxtx on windows (x-compiled with mingw) EXPERIMENTAL
start JACK first (if not already running)
start exe programs in directory 'bin'
see --help
audio_rxtx uses many other open software bits.
https://github.com/7890/jack_tools
this is free software. no warranty or support. see COPYING
