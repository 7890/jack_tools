test audio_rxtx on windows

** this is an initial build to test using mingw **



needs a running JACK, tested with 
Jack_v1.9.11_64_setup.exe


see --help

audio_rxtx uses many other open software bits. 

https://github.com/7890/jack_tools

see audio_rxtx

//tb/2014
/10

this is free software. no warranty. see COPYING
